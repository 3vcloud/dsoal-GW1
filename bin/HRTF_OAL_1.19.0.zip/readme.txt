Personalized HRTF tables for OpenAL Soft 1.19.0 or higher

(OpenAL Soft 1.19.0 uses 24-bit HRTF tables which aren't compatible with older versions like the customized Deus Ex version with lipsyncing)
--------
INSTALLATION INSTRUCTIONS:
--------
1.) Download OpenAL Soft 1.19.0 or higher from here and unzip it:
http://openal-soft.org/#download
2.) Rename the folder inside to just "OpenAL" and move it to %APPDATA%. On 64-bit OS, it should be located in C:\Users\yournamehere\AppData.
3.) Copy and paste the contents of this .zip file into C:\Users\yournamehere\AppData\OpenAL.
4.) Watch this video here to determine the right HRTF tables for you:
https://www.youtube.com/watch?v=VCXQp7swp5k
5.) Start alsoft-config.exe, set "Stereo Mode" to Headphones, "Frequency" to whatever your PC's config is set to (44100 or 48000), "HRTF Mode" to Force on, and "Preferred HRTF" to whichever HRTF in the video matched your profile.
(e.g. if your personalized HRTF is IRC_1037 and your PC is set to 44100Hz, then select IRC_1037_44100)

--------
LIST OF CONFIRMED COMPATIBLE GAMES:
--------
Using a combination of "soft_oal.dll" renamed to OpenAL32.dll, DSOAL, wrap_oal.dll, and A3D-Alchemy, it's possible to gain 3D positional audio in hundreds of games that use either OpenAL, DirectSound3D, or Aureal A3D.
https://web.archive.org/web/20130702030043/http://connect.creativelabs.com:80/alchemy/Lists/Games/AllItems.aspx
https://web.archive.org/web/20071118104848/http://www.soundblaster.com/eax/gaming/gamelist.asp
https://pcgamingwiki.com/wiki/Property:EAX_support
https://en.wikipedia.org/wiki/List_of_games_with_EAX_support
http://members.optushome.com.au/kirben/3dsoftware.html
https://www.openal.org/games/
https://pcgamingwiki.com/w/index.php?title=Special:Search&limit=500&offset=0&profile=default&search=openal
http://www.blueripplesound.com/compatible-games

--------
CREDITS:
--------
The .mhr files in this collection were processed from the following, freely-available sources with no restrictions as long as the following authors are cited:

MIT KEMAR tables copyrighted 1994 by MIT Media Laboratory;
Bill Gardner (billg@media.mit.edu) and Keith Martin (kdm@media.mit.edu)
http://sound.media.mit.edu/resources/KEMAR.html

CIAIR tables copyright 1999 by Itakura Laboratory and the Center for Integrated Acoustic Information Research (CIAIR) of Nagoya University;
Fumitada Itakura, Kazuya Takeda, Mikio Ikeda, Shoji Kajita, and Takanori Nishino.
http://www.sp.m.is.nagoya-u.ac.jp/HRTF/database.html

Contact for the IRCAM Listen HRTF Database:
Olivier Warusfel (olivier.warusfel@ircam.fr)
Room Acoustics Team, IRCAM
1, place Igor Stravinsky
75004 PARIS, France
http://recherche.ircam.fr/equipes/salles/listen/index.html